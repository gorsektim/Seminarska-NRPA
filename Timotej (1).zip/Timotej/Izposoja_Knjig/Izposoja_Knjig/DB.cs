﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Izposoja_Knjig
{
    public static class DB
    {
        public static string ConnecitonString { get; set; }

        static DB()
        {
            string jsonFilePath = "AppSettings.json";
            string jsonString = File.ReadAllText(jsonFilePath);
            dynamic jsonObject = JsonConvert.DeserializeObject(jsonString);
            ConnecitonString = jsonObject.connectionString;
        }

    }
}
