﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Izposoja_Knjig
{
    public partial class Form2 : Form
    {
        string connectionstring = DB.ConnecitonString;

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            refresh_Listbox();
        }
        class Avtor
        {
            public int id { get; set; }
            public string ime { get; set; }
            public string priimek { get; set; }
            public int letorojstva { get; set; }
            public override string ToString()
            {
                return ime + ", " + priimek + ", " + letorojstva;
            }
        }
        private void refresh_Listbox()
        {

            SqlConnection connection = new SqlConnection(connectionstring);

            try
            {
                // Odpremo povezavo s strežnikom
                connection.Open();

                // SQL stavek za izbiro podatkov iz tabele "Knjiga"
                string sqlQuery = "SELECT id_avtor,ime, priimek, leto_rojstva FROM Avtor";

                // Ustvarimo ukaz za izvajanje SQL stavka
                SqlCommand command = new SqlCommand(sqlQuery, connection);

                // Izvedemo SQL ukaz in pridobimo podatke
                SqlDataReader reader = command.ExecuteReader();

                // Prikaz podatkov v ListBox
                while (reader.Read())
                {
                    // Dodamo podatke v ListBox
                    int id = reader.GetInt32(0);
                    string ime = reader.GetString(1);
                    int letorojstva = reader.GetInt32(3);
                    string priimek = reader.GetString(2);

                    Avtor avtor = new Avtor();
                    avtor.id = id;
                    avtor.ime = ime;
                    avtor.priimek  = priimek;
                    avtor.letorojstva = letorojstva;

                    // Prikažemo podatke v ListBox
                    listBox1.Items.Add(avtor);
                }

                // Zapremo bralca in s tem povezavo s strežnikom
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Napaka pri pridobivanju podatkov: " + ex.Message);
            }
            finally
            {
                // Zapremo povezavo s strežnikom, ne glede na to, ali je prišlo do napake ali ne
                connection.Close();
            }
        }
       

        private void button2_Click_2(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Prosim izberite element, ki ga želite izbrisati.");
                return;
            }

            Avtor  avtor = listBox1.SelectedItem as Avtor;
            // Pridobimo izbrani element iz ListBox-a
            string selectedValue = avtor.ime;

            // Izvedemo SQL DELETE stavek za brisanje izbrane vrednosti iz podatkovne baze
            string sqlQuery = "DELETE FROM Avtor WHERE ime = @SelectedValue";

            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(sqlQuery, connection);
                    command.Parameters.AddWithValue("@SelectedValue", selectedValue);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Odstranimo izbrani element iz ListBox-a
                        listBox1.Items.Remove(selectedValue);
                        MessageBox.Show("Izbrani podatek je bil uspešno izbrisan iz baze in ListBox-a.");
                    }
                    else
                    {
                        MessageBox.Show("Izbranega podatka ni bilo mogoče izbrisati iz baze.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Napaka pri brisanju podatka: " + ex.Message);
                }
                listBox1.Items.Clear();
                refresh_Listbox();

            }

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            {
                // Preverimo, če so vsa polja izpolnjena
                if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text))
                {
                    MessageBox.Show("Prosim izpolnite vsa polja.");
                    return;
                }

                // Ustvarimo povezavo s SQL strežnikom
                SqlConnection connection = new SqlConnection(connectionstring);

                try
                {
                    // Odpremo povezavo s strežnikom
                    connection.Open();

                    // SQL stavek za vstavljanje podatkov v tabelo "Knjiga"
                    string sqlQuery = "INSERT INTO Avtor (ime, priimek, leto_rojstva) VALUES (@ime, @priimek, @leto_rojstva)";

                    // Ustvarimo ukaz za izvajanje SQL stavka
                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    // Dodamo parametre SQL stavku
                    command.Parameters.AddWithValue("@ime", textBox1.Text);
                    command.Parameters.AddWithValue("@priimek", textBox2.Text);
                    command.Parameters.AddWithValue("@leto_rojstva", textBox3.Text);

                    // Izvedemo SQL ukaz
                    int rowsAffected = command.ExecuteNonQuery();

                    // Preverimo, ali je bilo dodanih vrstic uspešno
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Podatki uspešno dodani v bazo.");
                        listBox1.Items.Clear();
                        refresh_Listbox();
                    }
                    else
                    {
                        MessageBox.Show("Prišlo je do težave pri dodajanju podatkov v bazo.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Napaka pri dodajanju podatkov v bazo: " + ex.Message);
                }
                finally
                {
                    // Zapremo povezavo s strežnikom, ne glede na to, ali je prišlo do napake ali ne
                    connection.Close();
                }

            }
        }
    }
}

