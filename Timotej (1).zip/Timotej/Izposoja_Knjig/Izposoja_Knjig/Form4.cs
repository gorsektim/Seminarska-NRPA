﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Izposoja_Knjig
{
    public partial class Form4 : Form
    {
        string connectionstring = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Izposoja_knjig.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
        public Form4()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        class Knjiga
        {
            public int id { get; set; }
            public string naslov { get; set; }
            public string kategorija { get; set; }
            public int letoizdaje { get; set; }
            public override string ToString()
            {
                return naslov + ", " + kategorija + ", " + letoizdaje;
            }
        }
        class Stranka
        {
            public int id { get; set; }
            public string ime { get; set; }
            public string priimek { get; set; }

            public Stranka(int id, string ime, string priimek)
            {
                this.id = id;
                this.ime = ime;
                this.priimek = priimek;
            }

            public override string ToString()
            {
                return ime + " " + priimek;
            }
        }
        private void refresh_Listbox()
        {

            listBox1.Items.Clear();

            SqlConnection connection = new SqlConnection(connectionstring);

            try
            {
                // Odpremo povezavo s strežnikom
                connection.Open();

                // SQL stavek za izbiro podatkov iz tabele "Knjiga"
                string sqlQuery = "SELECT id_knjiga ,naslov, leto_izdaje, kategorija FROM Knjiga WHERE id_knjiga NOT IN (SELECT id_knjiga FROM Izposoja WHERE datum_vrnitve IS NULL)";

                // Ustvarimo ukaz za izvajanje SQL stavka
                SqlCommand command = new SqlCommand(sqlQuery, connection);

                // Izvedemo SQL ukaz in pridobimo podatke
                SqlDataReader reader = command.ExecuteReader();

                // Prikaz podatkov v ListBox
                while (reader.Read())
                {
                    // Dodamo podatke v ListBox
                    int id = reader.GetInt32(0);
                    string naslov = reader.GetString(1);
                    int leto_izdaje = reader.GetInt32(2);
                    string kategorija = reader.GetString(3);

                    Knjiga knjiga = new Knjiga();
                    knjiga.id = id;
                    knjiga.naslov = naslov;
                    knjiga.letoizdaje = leto_izdaje;
                    knjiga.kategorija = kategorija;

                    // Prikažemo podatke v ListBox
                    listBox1.Items.Add(knjiga);
                }

                // Zapremo bralca in s tem povezavo s strežnikom
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Napaka pri pridobivanju podatkov: " + ex.Message);
            }
            finally
            {
                // Zapremo povezavo s strežnikom, ne glede na to, ali je prišlo do napake ali ne
                connection.Close();
            }
        }


        private void refresh_Listbox2()
        {

            listBox2.Items.Clear();
            SqlConnection connection = new SqlConnection(connectionstring);
            if (comboBox1.SelectedItem is null)
            {
                return;
            }
            Stranka stranka = comboBox1.SelectedItem as Stranka;
            int strnkaId = stranka.id;
            try
            {
                // Odpremo povezavo s strežnikom
                connection.Open();

                // SQL stavek za izbiro podatkov iz tabele "Knjiga"
                string sqlQuery = $"SELECT Knjiga.id_knjiga ,naslov, leto_izdaje, kategorija FROM Knjiga JOIN Izposoja ON Knjiga.id_knjiga = Izposoja.id_knjiga WHERE Izposoja.id_stranka = {strnkaId} AND Izposoja.datum_vrnitve IS NULL ";
                // Ustvarimo ukaz za izvajanje SQL stavka
                SqlCommand command = new SqlCommand(sqlQuery, connection);

                // Izvedemo SQL ukaz in pridobimo podatke
                SqlDataReader reader = command.ExecuteReader();

                // Prikaz podatkov v ListBox
                while (reader.Read())
                {
                    // Dodamo podatke v ListBox
                    int id = reader.GetInt32(0);
                    string naslov = reader.GetString(1);
                    int leto_izdaje = reader.GetInt32(2);
                    string kategorija = reader.GetString(3);

                    Knjiga knjiga = new Knjiga();
                    knjiga.id = id;
                    knjiga.naslov = naslov;
                    knjiga.letoizdaje = leto_izdaje;
                    knjiga.kategorija = kategorija;

                    // Prikažemo podatke v ListBox
                    listBox2.Items.Add(knjiga);
                }

                // Zapremo bralca in s tem povezavo s strežnikom
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Napaka pri pridobivanju podatkov: " + ex.Message);
            }
            finally
            {
                // Zapremo povezavo s strežnikom, ne glede na to, ali je prišlo do napake ali ne
                connection.Close();
            }
        }

        
        

            private void refresh_Groupbox()
            {

                SqlConnection connection = new SqlConnection(connectionstring);

                try
                {
                    // Odpremo povezavo s strežnikom
                    connection.Open();

                    // SQL stavek za izbiro podatkov iz tabele "Knjiga"
                    string sqlQuery = "SELECT * FROM Stranka";

                    // Ustvarimo ukaz za izvajanje SQL stavka
                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    // Izvedemo SQL ukaz in pridobimo podatke
                    SqlDataReader reader = command.ExecuteReader();

                    // Prikaz podatkov v ListBox
                    while (reader.Read())
                    {
                        int id = reader.GetInt32(0);
                        string ime = reader.GetString(1);
                        string priimek = reader.GetString(2);

                        Stranka stranka = new Stranka(id, ime, priimek);
                        comboBox1.Items.Add(stranka);
                    }

                    // Zapremo bralca in s tem povezavo s strežnikom
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Napaka pri pridobivanju podatkov: " + ex.Message);
                }
                finally
                {
                    // Zapremo povezavo s strežnikom, ne glede na to, ali je prišlo do napake ali ne
                    connection.Close();
                }
            }

        

        private void Form4_Load(object sender, EventArgs e)
        {
            refresh_Listbox();
            refresh_Groupbox();
        }

        private void button2_Click(object sender, EventArgs e)   //izposodi
        {
            if (listBox1.SelectedItem is null)
                return;
            if (comboBox1.SelectedItem is null)
                return;


            SqlConnection connection = new SqlConnection(connectionstring);
            // Odpremo povezavo s strežnikom
            connection.Open();

            Knjiga knjiga = listBox1.SelectedItem as Knjiga;
            int knjigaId = knjiga.id;

            Stranka stranka = comboBox1.SelectedItem as Stranka;
            int strankaId = stranka.id;

            string sqlInsertQuery = $"INSERT INTO Izposoja (id_stranka, id_knjiga) VALUES ('{strankaId}', '{knjigaId}')";

            // Ustvarimo ukaz za izvajanje SQL stavka za vstavljanje nove izposoje
            SqlCommand commandInsert = new SqlCommand(sqlInsertQuery, connection);

            // Izvedemo SQL ukaz za vstavljanje nove izposoje
            int rowsAffected = commandInsert.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Knjiga uspešno izposojena.");
            }
            else
            {
                MessageBox.Show("Napaka pri izposoji knjige.");
            }
            refresh_Listbox2();
            refresh_Listbox();
            connection.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            // Odpremo povezavo s strežnikom
            connection.Open();

            // SQL stavek za izbiro podatkov iz tabele "Knjiga"
            string id = comboBox1.SelectedItem.ToString();
            string[] split = id.Split(' ');
            string ime = split[0];
            string priim = split[1];
            string sqlQuery = "SELECT * FROM Stranka s JOIN Izposoja i ON s.id_stranka=i.id_stranka JOIN Knjiga k ON i.id_knjiga=k.id_knjiga WHERE ime=@ime AND priimek=@priimek";


            // Ustvarimo ukaz za izvajanje SQL stavka
            SqlCommand command = new SqlCommand(sqlQuery, connection);
            command.Parameters.AddWithValue("@ime", ime);
            command.Parameters.AddWithValue("@priimek", priim);

            // Izvedemo SQL ukaz in pridobimo podatke
            SqlDataReader reader = command.ExecuteReader();
            refresh_Listbox2();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem is null)
            {
                return;
            }

            Knjiga knjiga = listBox2.SelectedItem as Knjiga;
            int knjigaId = knjiga.id;

            SqlConnection connection = new SqlConnection(connectionstring);
            // Odpremo povezavo s strežnikom
            connection.Open();

            // Pridobimo izposojo, ki ustreza izbrani knjigi
            string sqlUpdateQuery = "UPDATE Izposoja SET datum_vrnitve = @datum_vrnitve WHERE id_knjiga = @knjigaId AND datum_vrnitve IS NULL";

            // Ustvarimo ukaz za izvajanje SQL stavka za posodobitev datuma_vrnitve
            SqlCommand commandUpdate = new SqlCommand(sqlUpdateQuery, connection);
            commandUpdate.Parameters.AddWithValue("@datum_vrnitve", DateTime.Now); // Datum trenutne vrnitve
            commandUpdate.Parameters.AddWithValue("@knjigaId", knjigaId);

            // Izvedemo SQL ukaz za posodobitev datuma_vrnitve
            int rowsAffected = commandUpdate.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Datum vrnitve knjige uspešno posodobljen.");
            }
            else
            {
                MessageBox.Show("Napaka pri posodabljanju datuma vrnitve knjige.");
            }
            refresh_Listbox();
            refresh_Listbox2();
            connection.Close();
        }
        private void InsertStranka(string ime, string priimek)
        {
            SqlConnection connection = new SqlConnection(connectionstring);

            try
            {
                // Odpremo povezavo s strežnikom
                connection.Open();

                // SQL stavek za vstavljanje nove stranke
                string sqlInsertQuery = "INSERT INTO Stranka (ime, priimek, emso, telefonska_stevilka) VALUES (@ime, @priimek, @emso, @telefonska_stevilka)";

                // Ustvarimo ukaz za izvajanje SQL stavka
                SqlCommand command = new SqlCommand(sqlInsertQuery, connection);
                command.Parameters.AddWithValue("@ime", ime);
                command.Parameters.AddWithValue("@priimek", priimek);
                command.Parameters.AddWithValue("@emso", 12333);
                command.Parameters.AddWithValue("@telefonska_stevilka", 33344445555);

                // Izvedemo SQL ukaz
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Stranka uspešno vstavljena.");
                }
                else
                {
                    MessageBox.Show("Napaka pri vstavljanju stranke.");
                }

                // Po uspešnem vstavljanju osvežimo GroupBox z novimi podatki
                refresh_Groupbox();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Napaka pri vstavljanju stranke: " + ex.Message);
            }
            finally
            {
                // Zapremo povezavo s strežnikom
                connection.Close();
            }
        }

    }
}
