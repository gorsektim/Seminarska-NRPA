﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Izposoja_Knjig
{
    public partial class Form5 : Form
    {
        string connectionstring = "Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\Izposoja_knjig.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";

        public Form5()
        {
            InitializeComponent();
        }
        class Knjiga
        {
            public int id { get; set; }
            public string naslov { get; set; }
            public string kategorija { get; set; }
            public int letoizdaje { get; set; }
            public override string ToString()
            {
                return naslov + ", " + kategorija + ", " + letoizdaje;
            }
        }
        private void refresh_Listbox()
        {

            SqlConnection connection = new SqlConnection(connectionstring);

            try
            {
                // Odpremo povezavo s strežnikom
                connection.Open();

                // SQL stavek za izbiro podatkov iz tabele "Knjiga"
                string sqlQuery = "SELECT id_knjiga ,naslov, leto_izdaje, kategorija FROM Knjiga";

                // Ustvarimo ukaz za izvajanje SQL stavka
                SqlCommand command = new SqlCommand(sqlQuery, connection);

                // Izvedemo SQL ukaz in pridobimo podatke
                SqlDataReader reader = command.ExecuteReader();

                // Prikaz podatkov v ListBox
                while (reader.Read())
                {
                    // Dodamo podatke v ListBox
                    int id = reader.GetInt32(0);
                    string naslov = reader.GetString(1);
                    int leto_izdaje = reader.GetInt32(2);
                    string kategorija = reader.GetString(3);

                    Knjiga knjiga = new Knjiga();
                    knjiga.id = id;
                    knjiga.naslov = naslov;
                    knjiga.letoizdaje = leto_izdaje;
                    knjiga.kategorija = kategorija;

                    // Prikažemo podatke v ListBox
                    listBox1.Items.Add(knjiga);
                }

                // Zapremo bralca in s tem povezavo s strežnikom
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Napaka pri pridobivanju podatkov: " + ex.Message);
            }
            finally
            {
                // Zapremo povezavo s strežnikom, ne glede na to, ali je prišlo do napake ali ne
                connection.Close();
            }
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            refresh_Listbox();
        }
        private void button2_Click(object sender, EventArgs e)
        {

            {
                // Preverimo, če so vsa polja izpolnjena
                if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text))
                {
                    MessageBox.Show("Prosim izpolnite vsa polja.");
                    return;
                }

                // Ustvarimo povezavo s SQL strežnikom
                SqlConnection connection = new SqlConnection(connectionstring);

                try
                {
                    // Odpremo povezavo s strežnikom
                    connection.Open();

                    // SQL stavek za vstavljanje podatkov v tabelo "Knjiga"
                    string sqlQuery = "INSERT INTO Knjiga (naslov, leto_izdaje, kategorija) VALUES (@naslov, @letoIzdaje, @kategorija)";

                    // Ustvarimo ukaz za izvajanje SQL stavka
                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    // Dodamo parametre SQL stavku
                    command.Parameters.AddWithValue("@naslov", textBox1.Text);
                    command.Parameters.AddWithValue("@letoIzdaje", textBox3.Text);
                    command.Parameters.AddWithValue("@kategorija", textBox2.Text);

                    // Izvedemo SQL ukaz
                    int rowsAffected = command.ExecuteNonQuery();

                    // Preverimo, ali je bilo dodanih vrstic uspešno
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Podatki uspešno dodani v bazo.");
                        listBox1.Items.Clear();
                        refresh_Listbox();
                    }
                    else
                    {
                        MessageBox.Show("Prišlo je do težave pri dodajanju podatkov v bazo.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Napaka pri dodajanju podatkov v bazo: " + ex.Message);
                }
                finally
                {
                    // Zapremo povezavo s strežnikom, ne glede na to, ali je prišlo do napake ali ne
                    connection.Close();
                }

            }

        }

        
        

        private void button2_Click_1(object sender, EventArgs e)
        {
            {
                // Preverimo, če so vsa polja izpolnjena
                if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text))
                {
                    MessageBox.Show("Prosim izpolnite vsa polja.");
                    return;
                }

                // Ustvarimo povezavo s SQL strežnikom
                SqlConnection connection = new SqlConnection(connectionstring);

                try
                {
                    // Odpremo povezavo s strežnikom
                    connection.Open();

                    // SQL stavek za vstavljanje podatkov v tabelo "Knjiga"
                    string sqlQuery = "INSERT INTO Knjiga (naslov, leto_izdaje, kategorija) VALUES (@naslov, @letoIzdaje, @kategorija)";

                    // Ustvarimo ukaz za izvajanje SQL stavka
                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    // Dodamo parametre SQL stavku
                    command.Parameters.AddWithValue("@naslov", textBox1.Text);
                    command.Parameters.AddWithValue("@letoIzdaje", textBox3.Text);
                    command.Parameters.AddWithValue("@kategorija", textBox2.Text);

                    // Izvedemo SQL ukaz
                    int rowsAffected = command.ExecuteNonQuery();

                    // Preverimo, ali je bilo dodanih vrstic uspešno
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Podatki uspešno dodani v bazo.");
                        listBox1.Items.Clear();
                        refresh_Listbox();
                    }
                    else
                    {
                        MessageBox.Show("Prišlo je do težave pri dodajanju podatkov v bazo.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Napaka pri dodajanju podatkov v bazo: " + ex.Message);
                }
                finally
                {
                    // Zapremo povezavo s strežnikom, ne glede na to, ali je prišlo do napake ali ne
                    connection.Close();
                }

            }


        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Prosim izberite element, ki ga želite izbrisati.");
                return;
            }

            Knjiga knjiga = listBox1.SelectedItem as Knjiga;
            // Pridobimo izbrani element iz ListBox-a
            string selectedValue = knjiga.naslov;

            // Izvedemo SQL DELETE stavek za brisanje izbrane vrednosti iz podatkovne baze
            string sqlQuery = "DELETE FROM Knjiga WHERE naslov = @SelectedValue";

            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(sqlQuery, connection);
                    command.Parameters.AddWithValue("@SelectedValue", selectedValue);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Odstranimo izbrani element iz ListBox-a
                        listBox1.Items.Remove(selectedValue);
                        MessageBox.Show("Izbrani podatek je bil uspešno izbrisan iz baze in ListBox-a.");
                    }
                    else
                    {
                        MessageBox.Show("Izbranega podatka ni bilo mogoče izbrisati iz baze.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Napaka pri brisanju podatka: " + ex.Message);
                }
                listBox1.Items.Clear();
                refresh_Listbox();

            }

        }
    }
}
